package ru.gosha.SG_Muwa;

public class DetectiveException extends Exception {
    DetectiveException(String message){
        super(message);
    }
}
